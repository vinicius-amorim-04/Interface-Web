# Atividade: Site temático sobre Python com Bootstrap

## 1. Situação-problema

A escola deseja produzir um pequeno portal para apresentar a linguagem Python
a estudantes que estão iniciando seus estudos em programação. O site deverá
ser informativo, responsivo, organizado e fácil de navegar em celulares,
tablets e computadores.

## 2. Objetivo

Desenvolver um site com múltiplas páginas utilizando HTML5, CSS e Bootstrap,
aplicando componentes, sistema de grid, responsividade, pesquisa e referências.

## 3. Organização

- Modalidade: dupla ou trio.
- Público-alvo: alunos do Ensino Médio.
- Tema: linguagem de programação Python.
- Entrega sugerida: repositório GitHub do grupo.
- Página inicial obrigatória: `index.html`.

## 4. Estrutura mínima

```text
projeto-bootstrap-python/
├── index.html
├── por-que-estudar.html
├── exemplos.html
├── aplicacoes.html
├── sobre.html
└── assets/
    └── css/
        └── style.css
```

## 5. Conteúdo das páginas

### `index.html`
Apresentar:
- breve definição de Python;
- histórico;
- linha do tempo;
- evolução da linguagem.

### `por-que-estudar.html`
Explicar:
- benefícios para estudantes;
- relação com raciocínio lógico;
- possibilidades profissionais;
- aprendizagem progressiva.

### `exemplos.html`
Incluir no mínimo quatro exemplos:
- entrada e saída;
- cálculo;
- estrutura de decisão;
- repetição ou listas.

### `aplicacoes.html`
Apresentar no mínimo seis áreas:
- desenvolvimento web;
- ciência de dados;
- inteligência artificial;
- automação;
- ciência e engenharia;
- educação ou jogos.

### `sobre.html`
Apresentar:
- integrantes;
- turma e disciplina;
- objetivo do site;
- componentes Bootstrap usados;
- referências conforme normas ABNT.

## 6. Requisitos técnicos

O projeto deve utilizar:

- Bootstrap 5;
- navbar responsiva;
- sistema de grid;
- cards;
- botões;
- badges ou alerts;
- ao menos um componente JavaScript, como accordion;
- arquivo CSS externo;
- atributo `alt` em todas as imagens adicionadas;
- links funcionando em todas as páginas;
- abordagem mobile first.

## 7. Etapas de desenvolvimento

1. Pesquisar o tema em fontes confiáveis.
2. Selecionar e resumir o conteúdo.
3. criar a estrutura de pastas.
4. Construir a navbar comum às páginas.
5. Desenvolver primeiro para telas pequenas.
6. Aplicar grid, cards e componentes.
7. Personalizar o visual no arquivo `style.css`.
8. Testar todos os links e tamanhos de tela.
9. Revisar ortografia e referências.
10. Publicar no GitHub.

## 8. Critérios de avaliação

| Critério | Pontos |
|---|---:|
| Estrutura e funcionamento das páginas | 2,0 |
| Aplicação correta do Bootstrap | 2,0 |
| Responsividade e navegabilidade | 1,5 |
| Qualidade e organização do conteúdo | 1,5 |
| Exemplos de Python | 1,0 |
| Design e personalização CSS | 1,0 |
| Referências ABNT e autoria | 0,5 |
| Organização do GitHub e commits | 0,5 |
| **Total** | **10,0** |

## 9. Desafios adicionais

- Adicionar modo escuro com `data-bs-theme`.
- Criar uma página de quiz.
- Inserir um modal com curiosidades.
- Publicar o site no GitHub Pages.
- Incluir uma seção com projetos Python criados pelo grupo.

## 10. Orientação sobre o modelo

Os arquivos fornecidos formam um exemplo completo. O grupo deverá estudar o
código e produzir sua própria versão, alterando textos, organização visual,
componentes e personalizações. Apenas copiar o modelo não demonstra domínio
dos conteúdos.
